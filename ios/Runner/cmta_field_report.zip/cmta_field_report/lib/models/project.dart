

class Project {
  String name;
  String email;
  String number;
  String location;
  String projectId;

  Project({this.name, this.number, this.location,this.projectId});

  // factory Project.fromSnapshot(DataSnapshot snapshot) {
  //   print(snapshot.value);
  //   Project project = new Project(
  //     name: snapshot.value['projectName'],
  //     number: snapshot.value['projectNumber'],
  //     location: snapshot.value['projectLocation']);
  //
  //   project.email = snapshot.value['email'];
  //   project.fid = snapshot.key;
  //   print("i am in factory printing key");
  //   print(snapshot.key);
  //
  //   return project;
  }

  // toJson() {
  //   return {
  //     "projectName": name,
  //     "projectNumber": number,
  //     "projectLocation": location,
  //     "email": email
  //   };
  // }
