

class Reports {
  String reportId;
  String reportProjectId;


  Reports({this.reportId,this.reportProjectId});


}