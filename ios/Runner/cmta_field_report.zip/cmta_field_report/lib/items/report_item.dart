import 'package:cmta_field_report/models/report.dart';
import 'package:flutter/material.dart';


class ReportListItem extends StatelessWidget {
  String fid;
  String projectFid;
  List<String> notes;
  String preparedBy;
  String punchListType;
  String siteVisitDate;

  ReportListItem({

   this.fid,this.notes,this.preparedBy,this.projectFid,this.punchListType,this.siteVisitDate
});

  @override
  Widget build(BuildContext context) {
    return new Padding(
      padding: EdgeInsets.all(16.0),
      child: new Row(children: [
        new Expanded(
          child: new Column(children: <Widget>[
            new Text(
              punchListType,
              textScaleFactor: 1.2,
              textAlign: TextAlign.left,
            ),
            new Text(
              siteVisitDate,
              textScaleFactor: 1.0,
              textAlign: TextAlign.right,
              style: new TextStyle(
                color: Colors.grey,
              ),
            )
          ], crossAxisAlignment: CrossAxisAlignment.start,)
        )
      ]),
    );
  }
}