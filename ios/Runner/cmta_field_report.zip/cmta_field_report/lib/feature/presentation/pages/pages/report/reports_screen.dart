import 'dart:async';
import 'dart:io' show Platform;

import 'package:cmta_field_report/core/utils/navigation.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/pages/pages/report/report_bloc.dart';
import 'package:flutter/material.dart';

import 'package:flutter_bloc/flutter_bloc.dart';

import '../issue/issue_screen.dart';
import '../addReport/add-report.dart';

import '../../../../../items/report_item.dart';


import '../../../../../models/report.dart';

class ReportsPage extends StatefulWidget {
  static const String routeName = '/report_page';

  final String profileId;

  ReportsPage({this.profileId});

  @override
  _ReportsPageState createState() {
    return new _ReportsPageState();
  }
}

class _ReportsPageState extends State<ReportsPage> {
  int i;
  String r;

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();

    // i++;
    // if (i == 1) {
     r = ModalRoute.of(context).settings.arguments;
    print("im printing profile id in report screen");
    print(r);
    BlocProvider.of<ReportBloc>(context).add(GetProjectListEvent(profileId: r));
    // }
  }

  List projects = [];

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("Reports"),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
         // Navigator.of(context).pop();

          Reports r=Reports(reportProjectId:ModalRoute.of(context).settings.arguments,reportId: null );
          Navigation.intentWithData(
              context, AddReportPage.routeName, r );
        },
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ),
      body: BlocConsumer<ReportBloc, ReportState>(listener: (context, state) {
        if (state is ErrorState &&
            state.message != null &&
            !state.message.isEmpty) {
          Utils.showErrorToast(state.message, context);
          // Navigation.back(context);
        } else if (state is LoadingState) {
          Utils.showProgressDialog(context);
        } else if (state is LoadedState) {
          /// Dismissing the progress screen
          print("sttae in screen");
          print(state.l);
          projects = state.l;
          Navigator.pop(context);
        }else if(state is DeletedState){
          Navigator.pop(context);
          Navigator.pop(context);
          BlocProvider.of<ReportBloc>(context).add(GetProjectListEvent(profileId: r));

        }
      }, builder: (context, state) {
        return ListView(
          children: getListofProject(projects),
        );
      }),
    );
  }

  List<Widget> getListofProject(List projects) {
    List<Widget> child = [];
    print("im in the method getlist ");
    print(projects);

    projects.forEach((element) {
      print("im inside the for each");

      List<String> n = [];

      Widget widget = GestureDetector(
          onTap: () {
            print("on report on tap");

            // Navigation.intentWithData(
            //     context, AddReportPage.routeName, element["Rpt_Id"]);



            Navigation.intentWithData(
                     context, IssuesPage.routeName, element["Rpt_Id"]);

          },
          onLongPress: (){
            Reports report=Reports(reportId:element["Rpt_Id"],reportProjectId: element["Rpt_Pj_Id"] );
            showDialog(
                context: context,
                builder: (BuildContext context) => _buildOptionsDialog(context,report)
            );
          },
          child: ReportListItem(
            notes: n,
            preparedBy: element["Rpt_PreparedBy"],
            punchListType: element["Rpt_PunchListType"],
            siteVisitDate: element["Rpt_VisitDate"],
          ));
      child.add(widget);
    });
    return child;
  }


_buildOptionsDialog(BuildContext conte, Reports report) {
  Widget cancelButton = FlatButton(
    child: Text("CANCEL"),
    onPressed: () {
      Navigator.of(context).pop();
    },
  );

  Widget editButton = FlatButton(
    child: Text("EDIT"),
    onPressed: () {
      Navigator.of(context).pop();
      Navigation.intentWithData(
          context, AddReportPage.routeName, report);

    },
  );

  Widget deleteButton = FlatButton(
    child: Text(
      "DELETE",
      style: new TextStyle(color: Colors.red),
    ),
    onPressed: () async {

      BlocProvider.of<ReportBloc>(context).add(DeleteReportEvent(reportId: report.reportId));

    },
  );

  return new AlertDialog(
      title: new Text("Report Options"),
      content: new Text("What would you like to do with your report?"),
      actions: [cancelButton, editButton, deleteButton]);
}

}
