part of 'addIssue_bloc.dart';

@immutable
abstract class AddIssueEvent extends Equatable {}



class AddIssue extends AddIssueEvent {

  final String isuId;
  final String isuReportId;
  final String isuLocation;
  final String isuDetails;
  final String isuStatus;
  final String issueImage;
  final bool isUpdate;

  AddIssue({this.issueImage,this.isuDetails,this.isuId,this.isuLocation,this.isuReportId,this.isuStatus,this.isUpdate});




  @override
  List<Object> get props => [issueImage,isuLocation,isuDetails,isuStatus,isuReportId,isuId];
}





class GetIssue extends AddIssueEvent{
  final String issueId;

  GetIssue({this.issueId});

  @override
  List<Object> get props => [issueId];
}

class LogoutEvent extends AddIssueEvent {
  @override
  List<Object> get props => [];
}

class GetMyProfileDetails extends AddIssueEvent {
  @override
  List<Object> get props => [];
}
