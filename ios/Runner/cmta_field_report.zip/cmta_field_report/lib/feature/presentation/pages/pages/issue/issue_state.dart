part of 'issue_bloc.dart';

@immutable
abstract class IssueState {}

class IssueInitial extends IssueState {

}

class LoadingState extends IssueState {
  final String name;
  final String emailId;
  final String profileImagePath;
  final String userType;

  LoadingState({this.name,this.emailId, this.profileImagePath,this.userType});
}

class ErrorState extends IssueState {
  final String message;

  ErrorState({this.message});

  @override
  List<Object> get props => [message];
}

class LoadedState extends IssueState {

  List l=[];

  LoadedState({this.l});
}

class DeletedIssueState extends IssueState {




}



class EmailSentState extends IssueState {

 final bool l;

  EmailSentState({this.l});
}


