import 'dart:async';

import 'package:cmta_field_report/core/utils/navigation.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/pages/pages/addIssue/add-issue.dart';
import 'package:cmta_field_report/models/issue.dart';

import 'package:flutter/material.dart';

import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../items/issue_item.dart';

import 'issue_bloc.dart';

class IssuesPage extends StatefulWidget {
  static const String routeName = '/issue_page';

  @override
  _IssuesPageState createState() {
    return new _IssuesPageState();
  }
}

class _IssuesPageState extends State<IssuesPage> {
  List projects = [];

  int i = 0;
  String r;

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();

    i++;
    if (i == 1) {
      setState(() {
        r = ModalRoute.of(context).settings.arguments;
        print("im printing profile id in issue screen");
        print(r);
        BlocProvider.of<IssueBloc>(context).add(GetIssueListEvent(reportId: r));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<IssueBloc, IssueState>(listener: (context, state) {
      if (state is ErrorState &&
          state.message != null &&
          !state.message.isEmpty) {
        Utils.showErrorToast(state.message, context);
        // Navigation.back(context);
      } else if (state is LoadingState) {
        Utils.showProgressDialog(context);
      } else if (state is LoadedState) {
        /// Dismissing the progress screen
        print("state in issue screen");
        print(state.l);
        projects = state.l;
        print(projects.length);

        Navigator.pop(context);
      } else if (state is EmailSentState) {
        print("SentSuccesfully");

        Navigator.pop(context);
      } else if (state is DeletedIssueState) {
        Navigator.pop(context);
        Navigator.pop(context);
        BlocProvider.of<IssueBloc>(context).add(GetIssueListEvent(reportId: r));

      }
    }, builder: (context, state) {
      return Scaffold(
          appBar: new AppBar(
            title: new Text("Issues"),
            actions: [
              new FlatButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) =>
                        _showExportDialog(context),
                  );
                },
                child: new Text(
                  "EXPORT",
                  style: TextStyle(color: Colors.white),
                ),
              )
            ],
          ),
          floatingActionButton: FloatingActionButton(
            onPressed: () {
              var issue = Issue(
                  issueId: null,
                  issueReportId: ModalRoute.of(context).settings.arguments);

              Navigation.intentWithData(context, AddIssuePage.routeName, issue);
            },
            tooltip: 'Increment',
            child: const Icon(Icons.add),
          ),
          body: ListView(
            children: getListofProject(projects),
          ));
    });
  }

  List<Widget> getListofProject(List projects) {
    List<Widget> child = [];
    print("im in the method getlist ");
    print(projects);
    print(projects.length);

    projects.forEach((element) {
      print("im inside the for each");
      print(element["Isu_Location"]);
      print(element["IssueImage"]);
      print(element["Isu_Status"]);
      print(element["Isu_Details"]);

      Widget widget = GestureDetector(
          onTap: () {
            var issue = Issue(
                issueReportId: element["Isu_Rpt_Id"],
                issueId: element["Isu_Id"]);

            print("hjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj");
            print(element["Isu_Id"]);
            print(issue.issueId);
            Navigation.intentWithData(context, AddIssuePage.routeName, issue);
          },
          onLongPress: () {
            showDialog(
                context: context,
                builder: (BuildContext context) =>
                    _buildOptionsDialog(context, element["Isu_Id"]));
          },
          child: IssueListItem(
              location: element["Isu_Location"],
              image: element["IssueImagePath_Report"],
              status: element["Isu_Status"],
              details: element["Isu_Details"]));
      child.add(widget);
    });
    return child;
  }

  String filename, email = "";

  _showExportDialog(BuildContext contextt) {
    return SimpleDialog(
      title: new Text("Export Report"),
      contentPadding: EdgeInsets.all(16.0),
      children: <Widget>[
        new TextField(
          textAlign: TextAlign.left,
          //controller: filenameController,
          onChanged: (value) {
            print(value);
            this.filename = value;
          },
          decoration: new InputDecoration(hintText: "Filename"),
        ),
        new TextField(
          textAlign: TextAlign.left,
          onChanged: (value) {
            print(value);
            this.email = value;
          },
          decoration: new InputDecoration(hintText: "Email"),
        ),
        new Divider(),
        new FlatButton(
          child: new Text("SEND"),
          onPressed: () {
            BlocProvider.of<IssueBloc>(context)
                .add(ExportPdfEvent(emailId: email, fileName: filename,reportId:r ));
            Navigator.pop(context);
          },
        )
      ],
    );
  }

  _buildOptionsDialog(BuildContext conte, String g) {
    Widget cancelButton = FlatButton(
      child: Text("CANCEL"),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );

    Widget deleteButton = FlatButton(
      child: Text("DELETE"),
      onPressed: () {
        BlocProvider.of<IssueBloc>(context).add(DeleteIssueEvent(issueId: g));

        Navigator.of(context).pop();
      },
    );

    return new AlertDialog(
        title: new Text("Issue Options"),
        content: new Text("What would you like to do with your issue?"),
        actions: [cancelButton, deleteButton]);
  }
//
// Future _openAddIssueScreen() async {
//   print("Open add issue screen");
//
//   WidgetBuilder builder = (BuildContext _) => AddIssuePage.add();
//   Issue issue = await Navigator.of(context)
//       .push(new MaterialPageRoute(builder: builder));
//
//   if (issue != null) {
//     print(issue.details);
//     issue.reportFid = report.fid;
//     _issuesRef.push().set(issue.toJson());
//   } else {
//     print("ISSUE IS NULL");
//   }
// }
//
// Future _openEditIssueScreen(Issue issue) async {
//   print("Open edit issue screen");
//
//   WidgetBuilder builder = (BuildContext _) => AddIssuePage.edit(issue);
//   Issue newIssue = await Navigator.of(context)
//       .push(new MaterialPageRoute(builder: builder));
//
//   if (newIssue != null) {
//     print(newIssue.details);
//     newIssue.reportFid = report.fid;
//     _issuesRef.child(issue.fid).set(newIssue.toJson());
//   } else {
//     print("NEW ISSUE IS NULL");
//   }
// }
}
