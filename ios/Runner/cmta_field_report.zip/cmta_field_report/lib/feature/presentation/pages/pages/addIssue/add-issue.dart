import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/pages/pages/issue/issue_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_native_image/flutter_native_image.dart';
import 'package:flutter_picker/flutter_picker.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart' as imagePicker;
import 'package:cmta_field_report/core/utils/navigation.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'dart:convert';
import 'dart:typed_data';

import '../../../../../models/issue.dart';
import 'addIssue_bloc.dart';

class AddIssuePage extends StatefulWidget {
  static const String routeName = '/addIssue_page';

  @override
  _AddIssuePageState createState() {
    return new _AddIssuePageState();
  }
}

class _AddIssuePageState extends State<AddIssuePage> {
  TextEditingController _detailsTextController, _locationTextController;
  String _details, _location, _image;
  String _status = "OPEN";
  File _imageFile;
  bool isUpdate = false;
  Issue r;

  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();

    r = ModalRoute
        .of(context)
        .settings
        .arguments;
    String issueId = r.issueId;
    String issueReport = r.issueReportId;

    print(r.issueReportId);
    if (issueId != null) {
      print("im printing profile id in add issue screen");
      print(r);
      BlocProvider.of<AddIssueBloc>(context).add(GetIssue(issueId: issueId));
      setState(() {
        isUpdate = true;
      });
    } else {
      print("new issue adding");
    }
  }

  String image;

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Add Issue"), actions: [
        new FlatButton(
          onPressed: () {
            if (_imageFile != null) {
              print("i am here image base code");
              List<int> imageBytes = _imageFile.readAsBytesSync();
              _image = base64Encode(imageBytes);
              print(_image);
              //print(_image);
            }

            if (_status == "") {
              showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text(
                          "Please make sure the 'status' field not empty."),
                      actions: <Widget>[
                        FlatButton(
                          child: Text("DONE"),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        )
                      ],
                    );
                  });
            } else {
              print("on save");
              print(_image);

              if (isUpdate) {
                BlocProvider.of<AddIssueBloc>(context).add(AddIssue(
                  isuStatus: _status,
                  isuReportId: r.issueReportId,
                  isuLocation: _locationTextController.text,
                  isuDetails: _detailsTextController.text,
                  issueImage: _image,
                  isuId: r.issueId,
                  isUpdate: true,
                ));
              } else {
                BlocProvider.of<AddIssueBloc>(context).add(AddIssue(
                    isuStatus: _status,
                    isuReportId: r.issueReportId,
                    isuLocation: _location,
                    isuDetails: _details,
                    issueImage: _image,
                    isuId: null,
                    isUpdate: false));
              }
            }
          },
          child: new Text("SAVE", style: TextStyle(color: Colors.white)),
        )
      ]),
      body:
      BlocConsumer<AddIssueBloc, AddIssueState>(listener: (context, state) {
        if (state is ErrorState &&
            state.message != null &&
            !state.message.isEmpty) {
          Utils.showErrorToast(state.message, context);
          // Navigation.back(context);
        } else if (state is LoadingState) {
          Utils.showProgressDialog(context);
        } else if (state is LoadedState) {
          /// Dismissing the progress screen
          print("sttae in screen");
          _detailsTextController =
          new TextEditingController(text: state.isuDetails);
          _locationTextController =
          new TextEditingController(text: state.isuLocation);
          _status = state.isuStatus;
          image=state.issueImage;


          Navigator.pop(context);
        } else if (state is AddIssueSucccessState) {
          Navigator.of(context).pop();
          Navigator.of(context).pop();
          Navigation.intentWithData(
              context, IssuesPage.routeName, r.issueReportId);
        }
      }, builder: (context, state) {
        return ListView(
          shrinkWrap: true,
          padding: EdgeInsets.all(8.0),
          children: [
            new ListTile(
                leading: new Text("Issue Location"),
                title: new TextField(
                  autocorrect: true,
                  controller: _locationTextController,
                  onChanged: (value) => _location = value,
                )),
            new ListTile(
                leading: new Text("Issue Details   "),
                title: new TextField(
                  autocorrect: true,
                  controller: _detailsTextController,
                  onChanged: (value) => _details = value,
                )),
            new ListTile(
              leading: new Text("Issue Status    "),
              title: new Text("$_status"),
              onTap: () async {
                FocusScope.of(context).requestFocus(new FocusNode());
                print("keybord off");
                await new Future.delayed(new Duration(milliseconds: 1500), () {
                  _showPunchTypePicker(context);
                });
              },
            ),
            new Divider(),
            new ListTile(
              leading: new FlatButton(
                child: new Text("CHOOSE PHOTO"),
                onPressed: () {
                  getImageFromGallery();
                },
              ),
              trailing: new FlatButton(
                child: new Text("TAKE PHOTO"),
                onPressed: () {
                  getImageFromCamera();
                },
              ),
            ),

            _imageFile == null ? Container() : _getImage(),

            image == null ? Container() : Container(
              child: new Image.network(image), height: 100, width: 100,),


          ],
        );
      }),
    );
  }

  Widget _getImage() {
    if (_image != "" && _imageFile == null) {
      Uint8List bytes = Base64Decoder().convert(_image);
      return new Center(child: Image.memory(bytes, fit: BoxFit.fill));
    } else if (_imageFile != null) {
      return new Center(child: Image.file(_imageFile, fit: BoxFit.fill));
    } else {
      return new Center(child: Text("No Image Selected"));
    }
  }

  Future getImageFromGallery() async {
    var imageFile = await imagePicker.ImagePicker.pickImage(
        source: imagePicker.ImageSource.gallery,
        maxHeight: 600.0,
        maxWidth: 600.0);

    setState(() {
      _imageFile = imageFile;
    });
  }

  Future<File> testCompressAndGetFile(File file, String targetPath) async {
    // var result = await FlutterImageCompress.compressAndGetFile(
    //   file.absolute.path, targetPath,
    //   quality: 50,
    // );
    // final int size = result.lengthSync();
    // print("Compressed Size = " + size.toString());
    // ImageProperties properties =
    //     await FlutterNativeImage.getImageProperties(file.path);
    // File compressedFile = await FlutterNativeImage.compressImage(file.path,
    //     quality: 80,
    //     targetWidth: 200,
    //     targetHeight: (properties.height * 200 / properties.width).round());
    return file;
  }

  Future getImageFromCamera() async {
    var imageFile = await imagePicker.ImagePicker.pickImage(
        source: imagePicker.ImageSource.camera,
        maxHeight: 600.0,
        maxWidth: 600.0);

    await ImageGallerySaver.saveImage(
        Uint8List.fromList(imageFile.readAsBytesSync()));
    final int size = File(imageFile.path).lengthSync();
    print("UnCompressed Size = " + size.toString());
    final file = await testCompressAndGetFile(
        File(imageFile.path), imageFile.path + ".jpg");
    int s = File(file.path).lengthSync();
    print("compressed Size=" + s.toString());

    if (await file.exists()) {
      setState(() {
        _imageFile = file;
      });
    }

    final _picker = ImagePicker();

    Future _getImagee(ImageSource source) async {
      /// Dismissing the chooser dialog

      final pickedFile = await _picker.getImage(source: source);
      final int size = File(pickedFile.path).lengthSync();
      print("UnCompressed Size = " + size.toString());
      final file = await testCompressAndGetFile(
          File(pickedFile.path), pickedFile.path + ".jpg");
      // final file=File(pickedFile.path);
      if (await file.exists()) {
        setState(() {
          //_profileImage = file;
        });
        // base64Image = base64Encode(file.readAsBytesSync());
      }
    }

    // 2. compress file and get file.
  }

  _showPunchTypePicker(BuildContext context) {
    List<String> punchTypes = ["OPEN", "CLOSED", "N/A"];

    new Picker(
        adapter: PickerDataAdapter<String>(pickerdata: punchTypes),
        hideHeader: true,
        textAlign: TextAlign.center,
        title: new Text("Select Punch List Type"),
        columnPadding: const EdgeInsets.all(8.0),
        onConfirm: (Picker picker, List value) {
          print(picker.getSelectedValues()[0]);

          setState(() => _status = picker.getSelectedValues()[0]);
        }).showDialog(context);
  }
}
