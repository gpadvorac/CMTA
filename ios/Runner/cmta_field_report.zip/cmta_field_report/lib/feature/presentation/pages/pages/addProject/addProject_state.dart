part of 'addProject_bloc.dart';

@immutable
abstract class AddProjectState {}

class AddProjectInitial extends AddProjectState {}

class LoadingState extends AddProjectState {
  LoadingState();
}

class ErrorState extends AddProjectState {
  final String message;

  ErrorState({this.message});

  @override
  List<Object> get props => [message];
}

class ProjectCreated extends AddProjectState{

}

class LoadedState extends AddProjectState {
  String pjId;
  String pjCustomerId;
  String pjNumber;

  String pjName;
  String pjLocation;

  LoadedState(
      {this.pjCustomerId,
      this.pjId,
      this.pjLocation,
      this.pjName,
      this.pjNumber});
}
