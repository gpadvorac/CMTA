package com.example.cmta_field_report;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
