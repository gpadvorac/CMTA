import 'package:cmta_field_report/models/project.dart';
import 'package:flutter/material.dart';


class ProjectListItem extends StatelessWidget {
  final Project project;
  
  ProjectListItem(this.project);

  @override
  Widget build(BuildContext context) {
    return new Padding(
      padding: EdgeInsets.all(16.0),
      child: new Row(children: [
        new Expanded(
          child: new Column(children: <Widget>[
            new Text(
              project.name,
              textScaleFactor: 1.5,
              textAlign: TextAlign.left,
            ),
            new Text(
              project.number,
              textScaleFactor: 0.8,
              textAlign: TextAlign.right,
              style: new TextStyle(
                color: Colors.grey,
              ),
            )
          ], crossAxisAlignment: CrossAxisAlignment.start,)
        )
      ]),
    );
  }
}