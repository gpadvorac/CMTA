class PublishTrace {
  String className;
  String methodName;
  String information1;
  String information2;
  String exceptionInformation;

  PublishTrace({this.className,
      this.exceptionInformation,
      this.information1,
      this.information2,
      this.methodName});
}
