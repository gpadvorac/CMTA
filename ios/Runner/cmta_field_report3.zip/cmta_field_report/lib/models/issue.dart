

class Issue {
  String issueId;
  String issueReportId;



  Issue({this.issueId,this.issueReportId});


}