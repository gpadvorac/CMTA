part of 'home_bloc.dart';

@immutable
abstract class HomeEvent extends Equatable {}

class GetProjectListEvent extends HomeEvent {
  @override
  List<Object> get props => [];
}

class LogoutEvent extends HomeEvent {
  @override
  List<Object> get props => [];
}

class GetMyProfileDetails extends HomeEvent {
  @override
  List<Object> get props => [];
}

class DeleteProjectEvent extends HomeEvent {
  final String projectId;

  DeleteProjectEvent({this.projectId});

  @override
  List<Object> get props => [projectId];
}
