import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:cmta_field_report/core/error/exceptions.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/bloc/authentication/authentication_bloc.dart';
import 'package:cmta_field_report/publish_trace.dart';
import 'package:device_info/device_info.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import "package:http/http.dart" as http;
import 'package:flutter_guid/flutter_guid.dart';
import 'package:uuid/uuid.dart';


part 'addProject_event.dart';

part 'addProject_state.dart';

class AddProjectBloc extends Bloc<AddProjectEvent, AddProjectState> {
  final AuthenticationBloc authenticationBloc;

  AddProjectBloc({
    this.authenticationBloc,
  })
      : assert(authenticationBloc != null),
        super(AddProjectInitial());

  @override
  Stream<AddProjectState> mapEventToState(AddProjectEvent event) async* {
    if (event is AddEvent) {
      yield LoadingState();
      String projectLocation = event.projectLocation;
      String projectNumber = event.projectNumber;
      String projectName = event.projectName;


      var trasactionId = Guid.newGuid;
      var projectId = (event.projectId==null)?Guid.newGuid:event.projectId;

      print(authenticationBloc.sharedPref.getEmailName());
      var userid=authenticationBloc.sharedPref.getEmailName();
      var baseUrl=authenticationBloc.sharedPref.getBaseUrl();

      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "153824AA-36CF-4447-9A94-ADE402CE6C53",
      };

     // var url = "http://cmtafr.crocodiledigital.net/api/ProjectController/ExecuteProjectSave/$trasactionId/$projectId/$projectCustmerID/$projectNumber/$projectName/$projectLocation";
     var url="$baseUrl/ProjectController/ExecuteProjectSave/$trasactionId/$projectId/$userid/$projectNumber/$projectName/$projectLocation";
      var response;
      print(url);

      try {
        response = await http.Client().put(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode==200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          yield ProjectCreated();
        }
      } on Exception catch (e) {
        PublishTrace(
            className: "homePage",
            exceptionInformation: e.toString(),
            methodName: "home project list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }

    if (event is GetProjectEvent) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));
      print(event.projectId);

      var userid=authenticationBloc.sharedPref.getEmailName();
      var baseUrl=authenticationBloc.sharedPref.getBaseUrl();
     var t=event.projectId;

      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "03FA64E2-DD8B-4884-86AA-11551C6F2E29",
      };

      var url =
          "$baseUrl/ProjectController/Project_GetById/$t";
      var response;

      try {
        response = await http.Client().get(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.status==200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          var b = json.decode(response.body);
          yield LoadedState(
              pjCustomerId: b["Pj_CUsr_Id"],
              pjId: b["Pj_Id"],
              pjNumber: b["Pj_Number"],
              pjLocation: b["Pj_Location"],
              pjName: b["Pj_Name"]);
        }else{
          var m=json.decode(response.body);
          var mm=m["Message"];
          getExceptionMethod(className: "issue Screen",methodName:"Delete Issue Method",userId:userid,baseUrl:baseUrl,exceptionInfo: mm);
        }
      } on Exception catch (e) {
        var m=json.decode(response.body);
        var mm=m["Message"];
        getExceptionMethod(className: "issue Screen",methodName:"Delete Issue Method",userId:userid,baseUrl:baseUrl,exceptionInfo: mm);
        PublishTrace(
            className: "homePage",
            exceptionInformation: e.toString(),
            methodName: "home project list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }
  }

  getExceptionMethod({
    String userId,
    String className,
    String methodName,
    String information1,
    String information2,
    String exceptionInfo,
    String  baseUrl}
      ) async{
    var trasactionId=Guid.newGuid;
    var deviceId =await getDeviceId();
    String osType=Platform.isIOS?"IOS":"Android";
    String osVersion="12";

    var headers = {
      "content-type": "application/json",
      "accept": "application/json",
      "apiKey": "480CFB8B-9628-481A-AB98-0002567D75A0",
    };
    String url="$baseUrl/ExceptionLogController/ExecuteExceptionLogLineSave/$trasactionId/$userId/$deviceId/$osType/$osVersion/$className/$methodName/$information1/$information2/$exceptionInfo";
    var response = await http.Client().get(url, headers: headers);

    print(response);
  }
  Future<String> getDeviceId() async {
    String id;

    final DeviceInfoPlugin deviceInfoPlugin = new DeviceInfoPlugin();

    try {
      if (Platform.isAndroid) {
        var build = await deviceInfoPlugin.androidInfo;
        id = build.androidId;

        print("printing device id");
        print(id);
      } else if (Platform.isIOS) {
        var build = await deviceInfoPlugin.iosInfo;
        id = build.identifierForVendor;
      }
    } on Exception {
      print('Failed to get Platform Information');
    }

    return id;
  }

}
