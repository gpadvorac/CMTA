import 'package:cmta_field_report/core/utils/navigation.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/pages/pages/addProject/addProject_bloc.dart';
import 'package:cmta_field_report/feature/presentation/pages/pages/home/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../models/project.dart';

class AddProjectPage extends StatefulWidget {
  static const String routeName = '/addProject_page';

  @override
  _AddProjectPageState createState() {
    return new _AddProjectPageState();
  }
}

class _AddProjectPageState extends State<AddProjectPage> {
  TextEditingController _nameController, _numberController, _locationController;
  String _name, _number, _location;

  String r;

  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();

    // i++;
    // if (i == 1) {

    r = ModalRoute.of(context).settings.arguments;

    if (r != null) {
      print("im printing profile id in add project  screen");
      print(r);
      BlocProvider.of<AddProjectBloc>(context)
          .add(GetProjectEvent(projectId: r));
    } else {
      print("new project create");
    }
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
          title:
              _name == "" ? new Text("Add Project") : new Text("Edit Project"),
          actions: [
            new FlatButton(
              onPressed: () {
                // if (_locationController.text == "" ||
                //     _nameController.text == "" ||
                //     _numberController.text == "") {
                //   showDialog(
                //       context: context,
                //       builder: (BuildContext context) {
                //         return AlertDialog(
                //           title: Text(
                //               "Please make sure all fields are not empty."),
                //           actions: <Widget>[
                //             FlatButton(
                //               child: Text("DONE"),
                //               onPressed: () {
                //                 Navigator.of(context).pop();
                //               },
                //             )
                //           ],
                //         );
                //       });
                // } else {
                // Navigator.of(context).pop(new Project(
                //     name: _name, number: _number, location: _location));
                print(_name);
                print(_number);
                print(_location);
                if (r == null) {
                  BlocProvider.of<AddProjectBloc>(context).add(AddEvent(
                      projectLocation: _location,
                      projectId: null,
                      projectName: _name,
                      projectNumber: _number));
                } else {
                  BlocProvider.of<AddProjectBloc>(context).add(AddEvent(
                      projectLocation: _locationController.text,
                      projectId: (r == null) ? null : r,
                      projectName: _nameController.text,
                      projectNumber: _numberController.text));
                }
              },
              child: new Text("SAVE", style: TextStyle(color: Colors.white)),
            )
          ]),
      body: BlocConsumer<AddProjectBloc, AddProjectState>(
          listener: (context, state) {
        if (state is ErrorState &&
            state.message != null &&
            !state.message.isEmpty) {
          Utils.showErrorToast(state.message, context);
          // Navigation.back(context);
        } else if (state is LoadingState) {
          Utils.showProgressDialog(context);
        } else if (state is LoadedState) {
          /// Dismissing the progress screen

          _nameController = new TextEditingController(text: state.pjName);
          _numberController = new TextEditingController(text: state.pjNumber);
          _locationController =
              new TextEditingController(text: state.pjLocation);
          Navigator.pop(context);
        } else if (state is ProjectCreated) {
          Navigation.intent(context, MyHomePage.routeName);
        }
      }, builder: (context, state) {
        return new Column(
          children: [
            new ListTile(
                title: new TextField(
              autocorrect: true,
              decoration: new InputDecoration(hintText: "Project Name"),
              controller: _nameController,
              onChanged: (value) => _name = value,
            )),
            new ListTile(
                title: new TextField(
              autocorrect: true,
              decoration: new InputDecoration(hintText: "Project Number"),
              controller: _numberController,
              onChanged: (value) => _number = value,
            )),
            new ListTile(
                title: new TextField(
              autocorrect: true,
              decoration: new InputDecoration(hintText: "Project Location"),
              controller: _locationController,
              onChanged: (value) => _location = value,
            )),
          ],
        );
      }),
    );
  }
}
