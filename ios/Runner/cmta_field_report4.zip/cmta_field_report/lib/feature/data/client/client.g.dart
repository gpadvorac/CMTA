// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'client.dart';

// **************************************************************************
// RetrofitGenerator
// **************************************************************************

class _RestClient implements RestClient {
  _RestClient(this._dio, {this.baseUrl}) {
    ArgumentError.checkNotNull(_dio, '_dio');
    baseUrl ??= 'https://createllc.dev/';
  }

  final Dio _dio;

  String baseUrl;

  @override
  Future<LoginRequestData> login(emailId, password) async {
    ArgumentError.checkNotNull(emailId, 'emailId');
    ArgumentError.checkNotNull(password, 'password');

    const _extra = <String, dynamic>{};
    final queryParameters = <String, dynamic>{};
    final _data = {'emailid': emailId, 'password': password};
    _data.removeWhere((k, v) => v == null);
    final _result = await _dio.request<Map<String, dynamic>>(
      '/login',
      queryParameters: queryParameters,
      options: RequestOptions(
          method: 'GET',
          headers: {
            "content-type": "application/json",
            "accept": "application/json",
            "apiKey": "13DD4209-F275-4471-BBBB-9B4F193DADF1",
            "userName": "catest@cmtaegrs.com",
            "password": "Cdaqt5e3swt5%"
          },
          extra: _extra,
          data: <String, dynamic>{},
          baseUrl:
              "http://cmtafr.crocodiledigital.net/api/CmtaUserController/Authenticate"),
    );
    final value = LoginRequestData.fromJson(_result.data);
    print("printing value in client");
    print(value);
    return value;
  }
}
