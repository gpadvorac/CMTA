import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:cmta_field_report/core/error/exceptions.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/bloc/authentication/authentication_bloc.dart';
import 'package:cmta_field_report/publish_trace.dart';
import 'package:device_info/device_info.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_guid/flutter_guid.dart';
import 'package:meta/meta.dart';
import "package:http/http.dart" as http;

part 'addReport_event.dart';

part 'addReport_state.dart';

class AddReportBloc extends Bloc<AddReportEvent, AddReportState> {
  final AuthenticationBloc authenticationBloc;

  AddReportBloc({
    this.authenticationBloc,
  })  : assert(authenticationBloc != null),
        super(AddReportInitial());

  @override
  Stream<AddReportState> mapEventToState(AddReportEvent event) async* {
    if (event is GetReportEvent) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));
      var t = event.reportId;
      var userid = authenticationBloc.sharedPref.getEmailName();
      var baseUrl = authenticationBloc.sharedPref.getBaseUrl();

      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "8047CAB4-B1EB-4562-B6F0-88C97EDECAAF",
      };

      var url =
          "$baseUrl/ReportController/Report_GetById/$t";
      var response;

      try {
        response = await http.Client().get(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode==200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          var b = json.decode(response.body);
          yield LoadedState(
              rptId: b["Rpt_Id"],
              rptPreparedBy: b["Rpt_PreparedBy"],
              rptProjectId: b["Rpt_Pj_Id"],
              rptPunchListType: b["Rpt_PunchListType"],
              rptVisitDate: b["Rpt_VisitDate"]);
        }else{
          var m=json.decode(response.body);
          var mm=m["Message"];
          getExceptionMethod(className: "issue Screen",methodName:"Delete Issue Method",userId:userid,baseUrl:baseUrl,exceptionInfo: mm);
        }
      } on Exception catch (e) {
        var m=json.decode(response.body);
        var mm=m["Message"];
        getExceptionMethod(className: "issue Screen",methodName:"Delete Issue Method",userId:userid,baseUrl:baseUrl,exceptionInfo: mm);
        PublishTrace(
            className: "homePage",
            exceptionInformation: e.toString(),
            methodName: "home project list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }
    if (event is AddReport) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));
      String preparedBy = event.rptPreparedBy;
      String reportVisitDate = event.rptVisitDate;
      String punchListType = event.rptPunchListType;

      var trasactionId = Guid.newGuid;
      var reportId = event.rptId;
      var reportProjectId = event.rptProjectId;
      var notes = event.notes;

      print(authenticationBloc.sharedPref.getEmailName());
      var userid = authenticationBloc.sharedPref.getEmailName();
      var baseUrl = authenticationBloc.sharedPref.getBaseUrl();

      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "0441012A-1AF5-4FCE-8780-9F6D98C4E25B",
      };

      var url;

      // var url = "$baseUrl/ReportController/ExecuteReportSave/$trasactionId/$reportId/$reportProjectId/$punchListType/$preparedBy/$reportVisitDate";
      //  var url="$baseUrl/ReportController/ExecuteReportSave/7DCC1892-961B-47C3-9203-CC71FD94E5F0/ /B367ADCD-9EA8-4802-971C-5C23EC960226/$punchListType/$preparedBy/$reportVisitDate";
      var response;
      print("mjnxkjnxkn,mnzmn");
      print(reportId);
      if (reportId == null) {
        print("im in the new creation");
        url =
            "$baseUrl/ReportController/ExecuteReportSave/$trasactionId/ /$reportProjectId/$punchListType/$preparedBy/$reportVisitDate/gggg";
      } else {
        print("im in the update");
        url =
            "$baseUrl/ReportController/ExecuteReportSave/$trasactionId/$reportId/$reportProjectId/$punchListType/$preparedBy/$reportVisitDate/gggg";
      }

      print(url);

      try {
        response = await http.Client().put(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode==200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          var b = json.decode(response.body);
          yield AddedState(message: b.toString());
        }
        else{
          var m=json.decode(response.body);
          var mm=m["Message"];
          getExceptionMethod(className: "issue Screen",methodName:"Delete Issue Method",userId:userid,baseUrl:baseUrl,exceptionInfo: mm);
        }
      } on Exception catch (e) {
        var m=json.decode(response.body);
        var mm=m["Message"];
        getExceptionMethod(className: "issue Screen",methodName:"Delete Issue Method",userId:userid,baseUrl:baseUrl,exceptionInfo: mm);
        PublishTrace(
            className: "homePage",
            exceptionInformation: e.toString(),
            methodName: "home project list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }
  }
  getExceptionMethod({
    String userId,
    String className,
    String methodName,
    String information1,
    String information2,
    String exceptionInfo,
    String  baseUrl}
      ) async{
    var trasactionId=Guid.newGuid;
    var deviceId =await getDeviceId();
    String osType=Platform.isIOS?"IOS":"Android";
    String osVersion="12";

    var headers = {
      "content-type": "application/json",
      "accept": "application/json",
      "apiKey": "480CFB8B-9628-481A-AB98-0002567D75A0",
    };
    String url="$baseUrl/ExceptionLogController/ExecuteExceptionLogLineSave/$trasactionId/$userId/$deviceId/$osType/$osVersion/$className/$methodName/$information1/$information2/$exceptionInfo";
    var response = await http.Client().get(url, headers: headers);

    print(response);
  }
  Future<String> getDeviceId() async {
    String id;

    final DeviceInfoPlugin deviceInfoPlugin = new DeviceInfoPlugin();

    try {
      if (Platform.isAndroid) {
        var build = await deviceInfoPlugin.androidInfo;
        id = build.androidId;

        print("printing device id");
        print(id);
      } else if (Platform.isIOS) {
        var build = await deviceInfoPlugin.iosInfo;
        id = build.identifierForVendor;
      }
    } on Exception {
      print('Failed to get Platform Information');
    }

    return id;
  }
}
