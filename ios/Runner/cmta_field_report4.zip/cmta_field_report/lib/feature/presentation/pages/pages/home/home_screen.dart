import 'dart:async';

import 'package:cmta_field_report/core/utils/navigation.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/pages/pages/addProject/add-project.dart';
import 'package:cmta_field_report/feature/presentation/pages/pages/login/login_screen.dart';
import 'package:cmta_field_report/feature/presentation/pages/pages/report/reports_screen.dart';

import 'package:cmta_field_report/items/project_item.dart';
import 'package:cmta_field_report/models/project.dart';

import 'package:flutter/material.dart';

import 'package:flutter_bloc/flutter_bloc.dart';

import 'home_bloc.dart';

class MyHomePage extends StatefulWidget {
  static const String routeName = '/home_page';

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  void initState() {
    super.initState();

    // database = FirebaseDatabase(app: widget.app);
    // database.setPersistenceEnabled(true);
    // database.setPersistenceCacheSizeBytes(10000000);
  }

  int i = 0;

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    i++;
    if (i == 1) {
      BlocProvider.of<HomeBloc>(context).add(GetProjectListEvent());
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  final project =
      Project(number: "123456", name: "demo", location: "Bangalore");

  List projects = [];

  @override
  Widget build(BuildContext contextt) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Projects'),
        leading: IconButton(
          icon: Icon(Icons.info),
          onPressed: () {
            showDialog(
                context: context,
                barrierDismissible: true,
                builder: (BuildContext contex) {
                  return AlertDialog(
                    title: Text("App Info"),
                    content: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text("Version Number: 1.29"),
                        Padding(
                          padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                        ),
                        Text("DeviceID: "),
                        Padding(
                          padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                        ),
                        Text("Email (userKey): " + " ")
                      ],
                    ),
                    actions: <Widget>[
                      FlatButton(
                        child: Text(
                          "OK",
                          style: TextStyle(color: Colors.green),
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      )
                    ],
                  );
                });
          },
        ),
        actions: <Widget>[
          FlatButton(
            child: Text(
              "LOGOUT",
              style: TextStyle(color: Colors.white),
            ),
            onPressed: () {
              showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (BuildContext con) {
                    return AlertDialog(
                      title: Text("Are you sure you want to logout?"),
                      actions: <Widget>[
                        FlatButton(
                          child: Text(
                            "NO",
                            style: TextStyle(color: Colors.red),
                          ),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        ),
                        FlatButton(
                          child: Text("YES"),
                          onPressed: () async {
                            BlocProvider.of<HomeBloc>(context).add(LogoutEvent());
                          },
                        )
                      ],
                    );
                  });
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigation.intentWithData(context, AddProjectPage.routeName, null);
        },
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ),
      body: BlocConsumer<HomeBloc, HomeState>(listener: (context, state) {
        if (state is ErrorState &&
            state.message != null &&
            !state.message.isEmpty) {
          Utils.showErrorToast(state.message, context);
          // Navigation.back(context);
        } else if (state is LoadingState) {
          Utils.showProgressDialog(context);
        } else if (state is LoadedState) {
          /// Dismissing the progress screen
          print("sttae in screen");
          print(state.l);
          projects = state.l;
          print(projects[0]);
          Navigator.pop(context);
        } else if (state is DeletedState) {
          Navigator.pop(context);
          Navigator.pop(context);
          BlocProvider.of<HomeBloc>(context).add(GetProjectListEvent());
        }
        else if(state is LogoutState){
          Navigation.intentWithClearAllRoutes(context, LoginPage.routeName);
        }
      }, builder: (context, state) {
        return ListView(
          children: getListofProject(projects),
        );
      }),
    );
  }

  List<Widget> getListofProject(List projects) {
    List<Widget> child = [];
    print("im in the method getlist ");
    print(projects);

    projects.forEach((element) {
      print("im inside the for each");

      final project = Project(
        number: element["Pj_Id"],
        name: element["Pj_Name"],
        location: element["Pj_Location"],
      );

      Widget widget = GestureDetector(
          onTap: () {
            print("on project clicked");
            Navigation.intentWithData(
                context, ReportsPage.routeName, project.number);
          },
          onLongPress: () {
            showDialog(
              context: context,
              builder: (BuildContext context) =>
                  _buildOptionsDialog(context, project.number),
            );
          },
          child: ProjectListItem(project));
      child.add(widget);
    });
    return child;
  }

  // Future _openAddProjectScreen() async {
  //   print("Open add project screen");
  //
  //   WidgetBuilder builder;
  //   builder = (BuildContext _) => AddProjectPage.add();
  //
  //   Project project = await Navigator.of(context)
  //       .push(new MaterialPageRoute<Project>(builder: builder));
  //
  //   if (project != null) {
  //     //Add project to Database and refresh list
  //     // print(project.name);
  //     // project.email = userKey;
  //     // _projectsRef.push().set(project.toJson()
  //     // );
  //   } else {
  //     print("PROJECT IS NULL");
  //   }
  // }

// Widget _buildHomePage() {
//   return Scaffold(
//
//     body: BlocConsumer<HomeBloc, HomeState>(listener: (context, state)
//   {
//       if (state is ErrorState &&
//           state.message != null &&
//           !state.message.isEmpty) {
//         Utils.showErrorToast(state.message, context);
//         // Navigation.back(context);
//       } else if (state is LoadingState) {
//         Utils.showProgressDialog(context);
//       } else if (state is LoadedState) {
//         /// Dismissing the progress screen
//
//
//
//       }
//     }, builder: (context, state) {
//       return ListView(
//
//   children: <Widget>[
//   // TODO: Implementation of a Firebase List that could be useful
//   Flexible(
//   child:
//
//
//   FirebaseAnimatedList(
//   key: ValueKey<bool>(true),
//   query: _projectsRef,
//
//   itemBuilder: (BuildContext context, DataSnapshot snapshot,
//   Animation<double> animation, int index) {
//   final project = new Project.fromSnapshot(snapshot);
//   return new InkWell(
//   onTap: () => _openReportsScreen(project),
//   onLongPress: () {
//   showDialog(
//   context: context,
//   builder: (BuildContext context) =>
//   _buildOptionsDialog(context, project),
//   );
//   },
//   child: new ProjectListItem(project));
//   },
//   ),
//   ),
//   ],
//   )
//   },
//     floatingActionButton: FloatingActionButton(
//       onPressed: () {
//         _openAddProjectScreen();
//       },
//       tooltip: 'Increment',
//       child: const Icon(Icons.add),
//     ),
//   );
// }

  _buildOptionsDialog(BuildContext conte, String projectId) {
    print("i am in the buildoption dialog");
    print(projectId);
    Widget cancelButton = FlatButton(
      child: Text("CANCEL"),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );

    Widget editButton = FlatButton(
      child: Text("EDIT"),
      onPressed: () {
        Navigation.intentWithData(context, AddProjectPage.routeName, projectId);
      },
    );

    Widget deleteButton = FlatButton(
      child: Text(
        "DELETE",
        style: new TextStyle(color: Colors.red),
      ),
      onPressed: () async {
        BlocProvider.of<HomeBloc>(context)
            .add(DeleteProjectEvent(projectId: projectId));
      },
    );

    return new AlertDialog(
        title: new Text("Project Options"),
        content: new Text("What would you like to do with your project?"),
        actions: [cancelButton, editButton, deleteButton]);
  }

// Future<void> _deleteReports(String projectId) async {
//   _userRef
//       .child('/reports')
//       .orderByChild('project')
//       .equalTo(projectId)
//       .onValue
//       .listen((data) async {
//     if (data.snapshot != null) {
//       print(data.snapshot.value.keys);
//       for (var key in data.snapshot.value.keys) {
//         await _deleteIssues(key);
//         _userRef.child('/reports/$key').remove();
//       }
//     }
//   });
// }
//
// Future<void> _deleteIssues(String reportId) {
//   _userRef
//       .child('/issues')
//       .orderByChild('report')
//       .equalTo(reportId)
//       .onValue
//       .listen((data) {
//     if (data.snapshot != null) {
//       for (var key in data.snapshot.value.keys) {
//         _userRef.child('/issues/$key').remove();
//       }
//     }
//   });
// }

  _openReportsScreen(Project project) {
    print("Open reports for project: ");

    WidgetBuilder builder;
    builder = (BuildContext _) => ReportsPage();

    Navigator.of(context).push(
        new MaterialPageRoute<void>(builder: builder, fullscreenDialog: false));
  }

// Future _openAddProjectScreen() async {
//   print("Open add project screen");
//
//   WidgetBuilder builder;
//   builder = (BuildContext _) => AddProjectPage.add();
//
//   Project project = await Navigator.of(context)
//       .push(new MaterialPageRoute<Project>(builder: builder));
//
//   if (project != null) {
//     //Add project to Database and refresh list
//     print(project.name);
//     project.email = userKey;
//     _projectsRef.push().set(project.toJson());
//   } else {
//     print("PROJECT IS NULL");
//   }
// }
//
// Future _openEditProjectScreen(Project project) async {
//   print("Opening edit project screen");
//
//   WidgetBuilder builder = (BuildContext _) => AddProjectPage.edit(project);
//
//   Project newProject = await Navigator.of(context)
//       .push(new MaterialPageRoute<Project>(builder: builder));
//
//   if (newProject != null) {
//     print(newProject.name);
//     newProject.email = userKey;
//     _projectsRef.child(project.fid).set(newProject.toJson());
//   }
// }
}
