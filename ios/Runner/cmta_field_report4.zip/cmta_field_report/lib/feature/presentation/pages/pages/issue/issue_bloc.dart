import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:cmta_field_report/core/error/exceptions.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/bloc/authentication/authentication_bloc.dart';
import 'package:cmta_field_report/publish_trace.dart';
import 'package:device_info/device_info.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_guid/flutter_guid.dart';
import 'package:meta/meta.dart';
import "package:http/http.dart" as http;

part 'issue_event.dart';

part 'issue_state.dart';

class IssueBloc extends Bloc<IssueEvent, IssueState> {
  final AuthenticationBloc authenticationBloc;

  IssueBloc({
    this.authenticationBloc,
  })  : assert(authenticationBloc != null),
        super(IssueInitial());

  @override
  Stream<IssueState> mapEventToState(IssueEvent event) async* {
    if (event is GetIssueListEvent) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));
      var baseUrl = authenticationBloc.sharedPref.getBaseUrl();
      var userid = authenticationBloc.sharedPref.getEmailName();
      var t = event.reportId;
      print(t);
      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "592D8645-EADB-47DF-93EF-093718F268D5",
      };

      // var url="http://cmtafr-dev.crocodiledigital.net/api/IssueController/Issue_GetListByFK/876b22d6-4293-4ab0-96d9-31475be19b18";

      var url = "$baseUrl/IssueController/Issue_GetListByFK/$t";
      print(url);
      var response;

      try {
        response = await http.Client().get(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode == 200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          print("im printing us ios");
          print(authenticationBloc.sharedPref.getUserName());
          yield LoadedState(l: json.decode(response.body));
        } else {
          print("jhkjhkjhkjhkjhkjh");
          var m = json.decode(response.body);
          var mm = m["Message"];
          getExceptionMethod(
              className: "issue Screen",
              methodName: "Delete Issue Method",
              userId: userid,
              baseUrl: baseUrl,
              exceptionInfo: mm);
          yield LoadedState(l: []);
        }
      } on Exception catch (e) {
        var m = json.decode(response.body);
        var mm = m["Message"];
        getExceptionMethod(
            className: "issue Screen",
            methodName: "Delete Issue Method",
            userId: userid,
            baseUrl: baseUrl,
            exceptionInfo: mm);
        PublishTrace(
            className: "homePage",
            exceptionInformation: e.toString(),
            methodName: "home project list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }

    if (event is DeleteIssueEvent) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));
      var baseUrl = authenticationBloc.sharedPref.getBaseUrl();
      var t = event.issueId;
      var tt = Guid.newGuid;
      print(t);
      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "22CF1ACE-A721-472C-8498-030AC32EDEB4",
      };
      var userid = authenticationBloc.sharedPref.getEmailName();

      // var url="http://cmtafr-dev.crocodiledigital.net/api/IssueController/Issue_GetListByFK/876b22d6-4293-4ab0-96d9-31475be19b18";

      var url = "$baseUrl/IssueController/Issue_SetDeleted_Flag/$tt/$t/true";
      print(url);
      var response;

      try {
        response = await http.Client().put(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode == 200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          print("im printing us ios");
          print(authenticationBloc.sharedPref.getUserName());
          yield DeletedIssueState();
        } else {
          var m = json.decode(response.body);
          var mm = m["Message"];
          getExceptionMethod(
              className: "issue Screen",
              methodName: "Delete Issue Method",
              userId: userid,
              baseUrl: baseUrl,
              exceptionInfo: mm);
        }
      } on Exception catch (e) {
        var m = json.decode(response.body);
        var mm = m["Message"];
        getExceptionMethod(
            className: "issue Screen",
            methodName: "Delete Issue Method",
            userId: userid,
            baseUrl: baseUrl,
            exceptionInfo: mm);
        PublishTrace(
            className: "homePage",
            exceptionInformation: e.toString(),
            methodName: "home project list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }

    if (event is ExportPdfEvent) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));

      var userid = authenticationBloc.sharedPref.getEmailName();
      var baseUrl = authenticationBloc.sharedPref.getBaseUrl();
      var trasactionId = Guid.newGuid;

      print("im calling pdf api");
      print(event.emailId);
      var email = event.emailId;
      var fileName = event.fileName;
      var reportId = event.reportId;
      String userName = authenticationBloc.sharedPref.getUserName();
      String password = authenticationBloc.sharedPref.getPassword();
      print(userName);
      print(password);
      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "13DD4209-F275-4471-BBBB-9B4F193DADF2",
        "userName": "catest@cmtaegrs.com",
        "password": "Cdaqt5e3swt5%",
        "email": email,
      };

      var url = "$baseUrl/CmtaUserController/EmailReport/$reportId/$fileName";
      var response;
      print(url);
      print(headers);

      try {
        response = await http.Client().get(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode == 200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          print("im printing us");
          print(authenticationBloc.sharedPref.getUserName());
          yield EmailSentState(l: true);
        } else {
          print("im in else");
          print(response.statusCode);
          yield EmailSentState(l: false);
          var m = json.decode(response.body);
          var mm = m["Message"];
          getExceptionMethod(
              className: "issue Screen",
              methodName: "Email Report",
              userId: userid,
              baseUrl: baseUrl,
              exceptionInfo: mm);
        }
      } on Exception catch (e) {
        var m = json.decode(response.body);
        var mm = m["Message"];
        getExceptionMethod(
            className: "issue Screen",
            methodName: "Email Report",
            userId: userid,
            baseUrl: baseUrl,
            exceptionInfo: mm);
        PublishTrace(
            className: "homePage",
            exceptionInformation: e.toString(),
            methodName: "home project list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }
  }

  getExceptionMethod(
      {String userId,
      String className,
      String methodName,
      String information1,
      String information2,
      String exceptionInfo,
      String baseUrl}) async {
    var trasactionId = Guid.newGuid;
    var deviceId = await getDeviceId();
    String osType = Platform.isIOS ? "IOS" : "Android";
    String osVersion = "12";

    var headers = {
      "content-type": "application/json",
      "accept": "application/json",
      "apiKey": "480CFB8B-9628-481A-AB98-0002567D75A0",
    };
    String url =
        "$baseUrl/ExceptionLogController/ExecuteExceptionLogLineSave/$trasactionId/$userId/$deviceId/$osType/$osVersion/$className/$methodName/$information1/$information2/$exceptionInfo";
    var response = await http.Client().get(url, headers: headers);

    print(response);
    print(url);
  }

  Future<String> getDeviceId() async {
    String id;

    final DeviceInfoPlugin deviceInfoPlugin = new DeviceInfoPlugin();

    try {
      if (Platform.isAndroid) {
        var build = await deviceInfoPlugin.androidInfo;
        id = build.androidId;

        print("printing device id");
        print(id);
      } else if (Platform.isIOS) {
        var build = await deviceInfoPlugin.iosInfo;
        id = build.identifierForVendor;
      }
    } on Exception {
      print('Failed to get Platform Information');
    }

    return id;
  }
}
