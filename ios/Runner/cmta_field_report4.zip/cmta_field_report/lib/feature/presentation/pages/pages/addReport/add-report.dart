import 'package:cmta_field_report/core/utils/navigation.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/pages/pages/addReport/addReport_bloc.dart';
import 'package:cmta_field_report/feature/presentation/pages/pages/report/reports_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_picker/flutter_picker.dart';
import 'package:intl/intl.dart';
import '../../../../../models/report.dart';

class AddReportPage extends StatefulWidget {
  static const String routeName = '/addReport_page';

  @override
  _AddReportPageState createState() {
    return new _AddReportPageState();
  }
}

class _AddReportPageState extends State<AddReportPage> {
  TextEditingController _preparedByController;
  String _preparedBy;
  String _siteVisitDate=DateFormat.yMMMd().format(DateTime.now());
    String _punchListType="IN WALL PUNCH LIST";
  String _note = "";
  List<String> _notes = [];

  Reports report;
  bool isUpdate = false;
  String reportProjectId;
  String reportId;

  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();

    // i++;
    // if (i == 1) {

    Reports report = ModalRoute.of(context).settings.arguments;
    reportId = report.reportId;
    reportProjectId = report.reportProjectId;
    print("lakshmi");
    print(reportProjectId);
    setState(() {
      isUpdate = true;
      reportProjectId = report.reportProjectId;
      reportId = report.reportId;
    });
    if (reportId != null) {
      print("im printing profile id in Add report screen");
      print(reportId);

      BlocProvider.of<AddReportBloc>(context)
          .add(GetReportEvent(reportId: reportId));
    } else {
      setState(() {
        isUpdate = false;
        reportProjectId = report.reportProjectId;
        reportId = report.reportId;
      });

      print("its new report creation");
    }
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Add Report"), actions: [
        new FlatButton(
          onPressed: () {
            if (_preparedBy == "" ||
                _punchListType == "" ||
                _siteVisitDate == "") {
              showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text("Please make sure all fields are not empty."),
                      actions: <Widget>[
                        FlatButton(
                          child: Text("DONE"),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        )
                      ],
                    );
                  });
            } else {
              print("project Id hhh");
              print(ModalRoute.of(context).settings.arguments);

              if (isUpdate == false) {
                BlocProvider.of<AddReportBloc>(context).add(AddReport(
                    rptVisitDate: _siteVisitDate,
                    rptPunchListType: _punchListType,
                    rptPreparedBy: _preparedBy,
                    rptId: null,
                    rptProjectId: reportProjectId));
              } else {
                BlocProvider.of<AddReportBloc>(context).add(AddReport(
                  rptVisitDate: _siteVisitDate,
                  rptPunchListType: _punchListType,
                  rptPreparedBy: _preparedBy,
                  rptProjectId: reportProjectId,
                  rptId: reportId,
                ));
              }
            }
          },
          child: new Text("SAVE", style: TextStyle(color: Colors.white)),
        )
      ]),
      body: BlocConsumer<AddReportBloc, AddReportState>(
          listener: (context, state) {
        if (state is ErrorState &&
            state.message != null &&
            !state.message.isEmpty) {
          Utils.showErrorToast(state.message, context);
          // Navigation.back(context);
        } else if (state is LoadingState) {
          Utils.showProgressDialog(context);
        } else if (state is LoadedState) {
          /// Dismissing the progress screen
          print("im in the state add project screen");
          print(state.rptId);
          _siteVisitDate = state.rptVisitDate;
          _punchListType = state.rptPunchListType;
          _preparedByController =
              new TextEditingController(text: state.rptPreparedBy);
          _notes = _notes;
          Navigator.pop(context);
        } else if (state is AddedState) {
          Navigator.of(context).pop();
          Navigator.of(context).pop();
          Navigation.intentWithData(
              context, ReportsPage.routeName, reportProjectId);


        }
      }, builder: (context, state) {
        return Column(
          children: [
            new ListTile(
                title: new TextField(
              autocorrect: true,
              decoration: new InputDecoration(hintText: "Prepared By"),
              controller: _preparedByController,
              onChanged: (value) => _preparedBy = value,
            )),
            new ListTile(
              leading: new Text("Punch Type"),
              title: new Text("$_punchListType", textAlign: TextAlign.right),
              onTap: () async {
                FocusScope.of(context).requestFocus(new FocusNode());
                print("keybord off");
                await new Future.delayed(new Duration(milliseconds: 1500), () {
                  _showPunchTypePicker(context);
                });
              },
            ),
            new ListTile(
              leading: new Text("Site Visit Date"),
              title: new Text("$_siteVisitDate", textAlign: TextAlign.right),
              onTap: () async {
                FocusScope.of(context).requestFocus(new FocusNode());
                print("keybord off");
                await new Future.delayed(new Duration(milliseconds: 1500), () {
                  _showDatePicker(context);
                });
              },
            ),
            new Divider(),
            new ListTile(
              leading: new Text("Notes"),
              trailing: new FlatButton(
                child: new Text("ADD NOTE"),
                onPressed: () {
                  //Add Note
                  showDialog(
                    context: context,
                    builder: (BuildContext context) =>
                        _showNoteDialog(context, -1),
                  );
                },
              ),
            ),
            new Expanded(
                child: ListView.builder(
                    padding: const EdgeInsets.all(16.0),
                    shrinkWrap: true,
                    itemCount: 0,
                    itemBuilder: (context, i) {
                      var note = _notes[i];
                      return _buildRow(note, i);
                    }))
          ],
        );
      }),
    );
  }

  _buildRow(String note, int noteIndex) {
    return new Column(children: [
      ListTile(
        contentPadding:
            new EdgeInsets.symmetric(vertical: 0.0, horizontal: 16.0),
        title: new Text(note),
        onTap: () {
          showDialog(
              context: context,
              builder: (BuildContext context) =>
                  _showNoteDialog(context, noteIndex));
        },
      ),
      new Divider()
    ]);
  }

  _showNoteDialog(BuildContext context, int noteIndex) {
    if (noteIndex == -1) {
      this._note = "";
    } else {
      this._note = _notes[noteIndex];
      print(this._note);
    }

    TextEditingController _noteController =
        new TextEditingController(text: this._note);

    return new SimpleDialog(
      title: noteIndex == -1 ? new Text("Add Note") : new Text("Edit Note"),
      contentPadding: EdgeInsets.all(24.0),
      children: <Widget>[
        new TextField(
          autocorrect: true,
          keyboardType: TextInputType.multiline,
          maxLines: 15,
          textAlign: TextAlign.left,
          controller: _noteController,
          onChanged: (value) => this._note = value,
        ),
        new Divider(),
        new Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            _isEditing(noteIndex),
            new FlatButton(
              child: new Text("FINISH"),
              onPressed: () {
                setState(() {
                  if (this._note != "" && noteIndex == -1) {
                    _notes.add(this._note);
                  } else {
                    _notes[noteIndex] = this._note;
                  }
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        )
      ],
    );
  }

  _isEditing(int noteIndex) {
    if (noteIndex != -1) {
      return new FlatButton(
          child: new Text(
            "DELETE",
            style: new TextStyle(color: Colors.red),
          ),
          onPressed: () {
            setState(() {
              _notes.removeAt(noteIndex);
              Navigator.of(context).pop();
            });
          });
    } else {
      return SizedBox(
        width: 0.0,
        height: 0.0,
      );
    }
  }

  _showPunchTypePicker(BuildContext context) {
    List<String> punchTypes = [
      "IN WALL PUNCH LIST",
      "ABOVE CEILING PUNCH LIST",
      "FINAL PUNCH LIST",
      "SITE OBSERVATION"
    ];

    new Picker(
        adapter: PickerDataAdapter<String>(pickerdata: punchTypes),
        hideHeader: true,
        textAlign: TextAlign.center,
        title: new Text("Select Punch List Type"),
        columnPadding: const EdgeInsets.all(4.0),
        onConfirm: (Picker picker, List value) {
          print(picker.getSelectedValues()[0]);

          setState(() => _punchListType = picker.getSelectedValues()[0]);
        }).showDialog(context);
  }

  _showDatePicker(BuildContext context) {
    new Picker(
        adapter: DateTimePickerAdapter(),
        hideHeader: true,
        title: new Text("Select Site Visit Date"),
        onConfirm: (Picker picker, List value) {
          var date = (picker.adapter as DateTimePickerAdapter).value;
          print(date);
          var formattedDate = DateFormat.yMMMd().format(date);
          print(formattedDate);

          setState(() => _siteVisitDate = formattedDate);
        }).showDialog(context);
  }
}
