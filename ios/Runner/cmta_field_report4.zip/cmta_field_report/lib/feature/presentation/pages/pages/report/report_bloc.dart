import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:cmta_field_report/core/error/exceptions.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/bloc/authentication/authentication_bloc.dart';
import 'package:cmta_field_report/publish_trace.dart';
import 'package:device_info/device_info.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_guid/flutter_guid.dart';
import 'package:meta/meta.dart';
import "package:http/http.dart" as http;

part 'report_event.dart';

part 'report_state.dart';

class ReportBloc extends Bloc<ReportEvent, ReportState> {
  final AuthenticationBloc authenticationBloc;

  ReportBloc({
    this.authenticationBloc,
  })  : assert(authenticationBloc != null),
        super(ReportInitial());

  @override
  Stream<ReportState> mapEventToState(ReportEvent event) async* {
    if (event is GetProjectListEvent) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));
      print(authenticationBloc.sharedPref.getEmailName());
      var userid=authenticationBloc.sharedPref.getEmailName();
      var baseUrl=authenticationBloc.sharedPref.getBaseUrl();
      print("im printing profile id");
      print(event.profileId);
      String r = event.profileId;
      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "639F1038-A77C-4401-9ECC-AB0C73CC2CF0",
      };

      var url =
          "$baseUrl/ReportController/Report_GetListByFK/{$r}";
      var response;

      try {
        response = await http.Client().get(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode == 200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          yield LoadedState(l: json.decode(response.body));
        }else{
          yield LoadedState(l: []);
          var m=json.decode(response.body);
          var mm=m["Message"];
          getExceptionMethod(className: "Report Screen",methodName:"Get Report List",userId: userid,baseUrl:baseUrl,exceptionInfo: mm);
        }
      } on Exception catch (e) {
        getExceptionMethod(className: "Report Screen",methodName:"Get Report List",userId: userid,baseUrl:baseUrl,exceptionInfo: response.body);
        PublishTrace(
            className: "ReportPage",
            exceptionInformation: e.toString(),
            methodName: "Report list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }


    if (event is DeleteReportEvent) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));
      print(authenticationBloc.sharedPref.getEmailName());
      var userid=authenticationBloc.sharedPref.getEmailName();
      var baseUrl=authenticationBloc.sharedPref.getBaseUrl();
      print("im printing repofile id");


      String r = event.reportId;
      print(r);
      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "7AD75D00-5D54-424A-8E16-501EB95B97A6",
      };

      var url = "$baseUrl/ReportController/Report_SetDeleted_Flag/46F9E12A-3C9D-4101-B6BE-3FC4BA2225AE/${r}/true";
      var response;

      try {
        response = await http.Client().put(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode == 200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          yield DeletedState(message: "Done");
        }else{
          yield LoadedState(l: []);
          var m=json.decode(response.body);
          var mm=m["Message"];
          print("hhhfgdg");
          print(m["Message"]);
          getExceptionMethod(className: "Report Screen",methodName:"Delete Report List",userId: userid,baseUrl:baseUrl,exceptionInfo:mm);
        }
      } on Exception catch (e) {
        var m=json.decode(response.body);
        var mm=m["Message"];
        print("hhhfgdg");
        print(m["Message"]);
        getExceptionMethod(className: "Report Screen",methodName:"Delete Report List",userId: userid,baseUrl:baseUrl,exceptionInfo: mm);
        PublishTrace(
            className: "ReportPage",
            exceptionInformation: e.toString(),
            methodName: "Report list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }
  }

  getExceptionMethod({
    String userId,
    String className,
    String methodName,
    String information1,
    String information2,
    String exceptionInfo,
    String  baseUrl}
      ) async{
    var trasactionId=Guid.newGuid;
    var deviceId =await getDeviceId();
    String osType=Platform.isIOS?"IOS":"Android";
    String osVersion="12";

    var headers = {
      "content-type": "application/json",
      "accept": "application/json",
      "apiKey": "480CFB8B-9628-481A-AB98-0002567D75A0",
    };
    String url="$baseUrl/ExceptionLogController/ExecuteExceptionLogLineSave/$trasactionId/$userId/$deviceId/$osType/$osVersion/$className/$methodName/$information1/$information2/$exceptionInfo";
    var response = await http.Client().get(url, headers: headers);

    print(response);
  }
  Future<String> getDeviceId() async {
    String id;

    final DeviceInfoPlugin deviceInfoPlugin = new DeviceInfoPlugin();

    try {
      if (Platform.isAndroid) {
        var build = await deviceInfoPlugin.androidInfo;
        id = build.androidId;

        print("printing device id");
        print(id);
      } else if (Platform.isIOS) {
        var build = await deviceInfoPlugin.iosInfo;
        id = build.identifierForVendor;
      }
    } on Exception {
      print('Failed to get Platform Information');
    }

    return id;
  }
}
