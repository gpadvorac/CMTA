import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:cmta_field_report/core/error/exceptions.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/bloc/authentication/authentication_bloc.dart';
import 'package:cmta_field_report/publish_trace.dart';
import 'package:device_info/device_info.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_guid/flutter_guid.dart';
import 'package:meta/meta.dart';
import "package:http/http.dart" as http;
import 'package:shared_preferences/shared_preferences.dart';

part 'home_event.dart';

part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final AuthenticationBloc authenticationBloc;

  HomeBloc({
    this.authenticationBloc,
  })  : assert(authenticationBloc != null),
        super(HomeInitial());

  @override
  Stream<HomeState> mapEventToState(HomeEvent event) async* {
    if (event is GetProjectListEvent) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));

      print(authenticationBloc.sharedPref.getEmailName());
      var userid = authenticationBloc.sharedPref.getEmailName();
      var baseUrl = authenticationBloc.sharedPref.getBaseUrl();

      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "E6178465-AD1F-430C-B4BC-B7DD3087BA22",
      };

      var url = "$baseUrl/ProjectController/Project_GetListByFK/$userid";
      var response;

      try {
        response = await http.Client().get(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode==200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          yield LoadedState(l: json.decode(response.body));
        }else{
          var m=json.decode(response.body);
          var mm=m["Message"];
          print("hhhfgdg");
          print(m["Message"]);
          getExceptionMethod(className: "Home Screen",methodName:"Get project List",userId: userid,baseUrl:baseUrl,exceptionInfo:mm);
        }
      } on Exception catch (e) {
        var m=json.decode(response.body);
        var mm=m["Message"];
        print("hhhfgdg");
        print(m["Message"]);
        getExceptionMethod(className: "Home Screen",methodName:"Get project List",userId: userid,baseUrl:baseUrl,exceptionInfo: mm);

        PublishTrace(
            className: "homePage",
            exceptionInformation: e.toString(),
            methodName: "home project list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);

      }
    }

    if(event is LogoutEvent){

      authenticationBloc.sharedPref.saveUserName(null);
      authenticationBloc.sharedPref.savePassword(null);
      authenticationBloc.sharedPref
          .saveEmailName(null);
      _updatePreferences(false);
      authenticationBloc.sharedPref.userLoggedIn(false);
      SharedPreferences _preff;
      _preff ??= await SharedPreferences.getInstance();
      _preff.setBool("USER_LOGGEDIN", false);
      print("logout");
      print(_preff.getBool("USER_LOGGEDIN"));
      yield LogoutState();
    }

    if (event is DeleteProjectEvent) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));

      String project = event.projectId;

      print(authenticationBloc.sharedPref.getEmailName());
      var userid = authenticationBloc.sharedPref.getEmailName();
      var baseUrl = authenticationBloc.sharedPref.getBaseUrl();
      var trasactionId = Guid.newGuid;

      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "480CFB8B-9628-481A-AB98-0002567D75A0",
      };

      var url =
          "$baseUrl/ProjectController/Project_SetDeleted_Flag/$trasactionId/$project/true";
      var response;

      try {
        response = await http.Client().put(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode == 200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          yield DeletedState(message: "Done");
        } else {
          var m=json.decode(response.body);
          var mm=m["Message"];
          print("hhhfgdg");
          print(m["Message"]);
          getExceptionMethod(className: "Home Screen",methodName:"Delete Project",userId: userid,baseUrl:baseUrl,exceptionInfo:mm);
        }
      } on Exception catch (e) {
        var m=json.decode(response.body);
        var mm=m["Message"];
        print("hhhfgdg");
        print(m["Message"]);

        getExceptionMethod(className: "Home Screen",methodName:"Get project List",userId: userid,baseUrl:baseUrl,exceptionInfo: mm);

        PublishTrace(
            className: "homePage",
            exceptionInformation: e.toString(),
            methodName: "home project list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }
  }
  _updatePreferences(bool value) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool("LOGGED_IN", value);
  }

  getExceptionMethod({
    String userId,
    String className,
    String methodName,
    String information1,
    String information2,
    String exceptionInfo,
     String  baseUrl}
  ) async{
    var trasactionId=Guid.newGuid;
    var deviceId =await getDeviceId();
    String osType=Platform.isIOS?"IOS":"Android";
    String osVersion="12";

    var headers = {
      "content-type": "application/json",
      "accept": "application/json",
      "apiKey": "480CFB8B-9628-481A-AB98-0002567D75A0",
    };
 String url="$baseUrl/ExceptionLogController/ExecuteExceptionLogLineSave/$trasactionId/$userId/$deviceId/$osType/$osVersion/$className/$methodName/$information1/$information2/$exceptionInfo";
   var response = await http.Client().get(url, headers: headers);

   print(response.statusCode);
   print(url);
  }
  Future<String> getDeviceId() async {
    String id;

    final DeviceInfoPlugin deviceInfoPlugin = new DeviceInfoPlugin();

    try {
      if (Platform.isAndroid) {
        var build = await deviceInfoPlugin.androidInfo;
        id = build.androidId;

        print("printing device id");
        print(id);
      } else if (Platform.isIOS) {
        var build = await deviceInfoPlugin.iosInfo;
        id = build.identifierForVendor;
      }
    } on Exception {
      print('Failed to get Platform Information');
    }

    return id;
  }
}
