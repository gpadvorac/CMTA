import 'dart:async';
import 'dart:convert';
import 'dart:io';



import 'package:bloc/bloc.dart';
import 'package:cmta_field_report/core/error/exceptions.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/presentation/bloc/authentication/authentication_bloc.dart';
import 'package:cmta_field_report/publish_trace.dart';
import 'package:device_info/device_info.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_guid/flutter_guid.dart';
import 'package:meta/meta.dart';
import "package:http/http.dart" as http;
import 'package:dio/dio.dart';


part 'addissue_event.dart';

part 'addIssue_state.dart';

class AddIssueBloc extends Bloc<AddIssueEvent, AddIssueState> {
  final AuthenticationBloc authenticationBloc;

  AddIssueBloc({
    this.authenticationBloc,
  })  : assert(authenticationBloc != null),
        super(AddIssueInitial());

  @override
  Stream<AddIssueState> mapEventToState(AddIssueEvent event) async* {
    if (event is GetIssue) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));
      var baseUrl=authenticationBloc.sharedPref.getBaseUrl();

      var t = event.issueId;
      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "26EE74FA-004A-4007-ADD0-785877FDF951",
      };

      var url =
          "$baseUrl/IssueController/Issue_GetById/$t";
      var response;
      var userid = authenticationBloc.sharedPref.getEmailName();


      try {
        response = await http.Client().get(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode ==200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          var b = json.decode(response.body);
          yield LoadedState(
              issueImage: b["IssueImagePath_Report"],
              isuDetails: b["Isu_Details"],
              isuId: b["Isu_Id"],
              isuLocation: b["Isu_Location"],
              isuReportId: b["Isu_Rpt_Id"],
              isuStatus: b["Isu_Status"]);
        }else{
          var m=json.decode(response.body);
          var mm=m["Message"];
          getExceptionMethod(className: "issue Screen",methodName:"Delete Issue Method",userId:userid,baseUrl:baseUrl,exceptionInfo: mm);
        }
      } on Exception catch (e) {
        var m=json.decode(response.body);
        var mm=m["Message"];
        getExceptionMethod(className: "issue Screen",methodName:"Delete Issue Method",userId:userid,baseUrl:baseUrl,exceptionInfo: mm);
        PublishTrace(
            className: "homePage",
            exceptionInformation: e.toString(),
            methodName: "home project list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }

    if (event is AddIssue) {
      yield LoadingState();
      // final useCase = await loginUseCase.call(LoginParam(
      //   emailId: event.userId,
      //   password: event.password,
      // ));
      String issueReportId = event.isuReportId;
      String issueStatus = event.isuStatus;
      String issueDetails = event.isuDetails;
      String issueLocation = event.isuLocation;
      String image=event.issueImage;
print("im in the add issue bloc printing image");
print(image);

      var issueId = (event.isuId==null)?Guid.newGuid:event.isuId;

      var trasactionId = Guid.newGuid;
      var reportId = Guid.newGuid;
      var reportProjectId = Guid.newGuid;

      print(authenticationBloc.sharedPref.getEmailName());
      var userid = authenticationBloc.sharedPref.getEmailName();
      var baseUrl = authenticationBloc.sharedPref.getBaseUrl();


      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "05ED5C03-648D-447A-8D04-8F35D30124BD",
      };
      var body = {"file": event.issueImage};

      // var url = "$baseUrl/ReportController/ExecuteReportSave/$trasactionId/$reportId/$reportProjectId/$punchListType/$preparedBy/$reportVisitDate";
      var url =
          "$baseUrl/IssueController/ExecuteIssueSave/$trasactionId/$issueId/$issueReportId/$issueLocation/$issueDetails/$issueStatus";
      var response;

      print(url);

      try {

        FormData formData = new FormData.fromMap({
          "file": new File(""),
        });
        response = await http.Client().put(url, headers: headers,body: image);

        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.statusCode==200) {
          print("im printing response in the loaded data in bloc home");
          print(response.body);
          var b = json.decode(response.body);
          yield AddIssueSucccessState(message: response.statusCode);
        }else{
          var m=json.decode(response.body);
          var mm=m["Message"];
          getExceptionMethod(className: "issue Screen",methodName:"Delete Issue Method",userId:userid,baseUrl:baseUrl,exceptionInfo: mm);
        }
      } on Exception catch (e) {
        var m=json.decode(response.body);
        var mm=m["Message"];
        getExceptionMethod(className: "issue Screen",methodName:"Delete Issue Method",userId:userid,baseUrl:baseUrl,exceptionInfo: mm);
        PublishTrace(
            className: "homePage",
            exceptionInformation: e.toString(),
            methodName: "home project list call");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }
  }

  getExceptionMethod({
    String userId,
    String className,
    String methodName,
    String information1,
    String information2,
    String exceptionInfo,
    String  baseUrl}
      ) async{
    var trasactionId=Guid.newGuid;
    var deviceId =await getDeviceId();
    String osType=Platform.isIOS?"IOS":"Android";
    String osVersion="12";

    var headers = {
      "content-type": "application/json",
      "accept": "application/json",
      "apiKey": "480CFB8B-9628-481A-AB98-0002567D75A0",
    };
    String url="$baseUrl/ExceptionLogController/ExecuteExceptionLogLineSave/$trasactionId/$userId/$deviceId/$osType/$osVersion/$className/$methodName/$information1/$information2/$exceptionInfo";
    var response = await http.Client().get(url, headers: headers);

    print(response);
  }
  Future<String> getDeviceId() async {
    String id;

    final DeviceInfoPlugin deviceInfoPlugin = new DeviceInfoPlugin();

    try {
      if (Platform.isAndroid) {
        var build = await deviceInfoPlugin.androidInfo;
        id = build.androidId;

        print("printing device id");
        print(id);
      } else if (Platform.isIOS) {
        var build = await deviceInfoPlugin.iosInfo;
        id = build.identifierForVendor;
      }
    } on Exception {
      print('Failed to get Platform Information');
    }

    return id;
  }
}
