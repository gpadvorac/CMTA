import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:cmta_field_report/core/error/exceptions.dart';
import 'package:cmta_field_report/core/error/failures.dart';
import 'package:cmta_field_report/core/utils/utils.dart';
import 'package:cmta_field_report/feature/domain/entities/login_response_entity.dart';
import 'package:cmta_field_report/feature/domain/usecase/login_usecase.dart';
import 'package:cmta_field_report/feature/presentation/bloc/authentication/authentication_bloc.dart';
import 'package:device_info/device_info.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_guid/flutter_guid.dart';
import "package:http/http.dart" as http;

import 'package:meta/meta.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../../publish_trace.dart';

part 'login_event.dart';

part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final AuthenticationBloc authenticationBloc;
  final LoginUseCase loginUseCase;

  LoginBloc(
      {@required AuthenticationBloc authenticationBloc,
      @required LoginUseCase loginUseCase})
      : assert(authenticationBloc != null),
        authenticationBloc = authenticationBloc,
        loginUseCase = loginUseCase,
        super(LoginInitial());

  @override
  Stream<LoginState> mapEventToState(
    LoginEvent event,
  ) async* {
    if (event is LoginUserEvent) {
      yield LoadingState();

      const USER_LOGGEDIN = "";
      SharedPreferences _preff;
      _preff ??= await SharedPreferences.getInstance();
      print("in the bloc");
      print(event.password);
      print(event.userId);
      print(authenticationBloc.sharedPref.getBaseUrl());
      var baseurl = authenticationBloc.sharedPref.getBaseUrl();

      var headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "apiKey": "13DD4209-F275-4471-BBBB-9B4F193DADF1",
        "userName": "catest@cmtaegrs.com",
        "password": "Cdaqt5e3swt5%"
      };

      var url = "$baseurl/CmtaUserController/Authenticate";
      var response;

      try {
        response = await http.Client().get(url, headers: headers);
        print(response.statusCode);
        print(response.body);
        if (response.body == null) {
          throw ValidationException(message: response.body);
        } else if (response.body != null) {
          print("im printing response in the loaded data in bloc login");

          if (response.statusCode == 200) {
            authenticationBloc.sharedPref.saveUserName(event.userId);
            authenticationBloc.sharedPref.savePassword(event.password);
            authenticationBloc.sharedPref
                .saveEmailName(jsonDecode(response.body));
            _updatePreferences(true);
            authenticationBloc.sharedPref.userLoggedIn(true);
            await _preff.setBool("USER_LOGGEDIN", true);
            print("devu");
            print(_preff.getBool("USER_LOGGEDIN"));
          } else {
            var m=json.decode(response.body);
            var mm=m["Message"];
            print("hhhfgdg");
            print(m["Message"]);
            getExceptionMethod(
                className: "Login Screen",
                methodName: "Get Report List",
                userId: "null",
                baseUrl: baseurl,
                exceptionInfo: mm);
          }

          yield LoadedState(userInformation: response.statusCode);
        }
      } on Exception catch (e) {


        getExceptionMethod(
            className: "Login Screen",
            methodName: "Get Report List",
            userId: "null",
            baseUrl: baseurl,
            exceptionInfo:e.toString());
        PublishTrace(
            className: "LoginPage",
            exceptionInformation: e.toString(),
            methodName: "login");
        throw ServerException(message: Utils.ERROR_NO_RESPONSE);
      }
    }
  }

  _updatePreferences(bool value) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool("LOGGED_IN", value);
  }

  getExceptionMethod(
      {String userId,
      String className,
      String methodName,
      String information1="",
      String information2="",
      String exceptionInfo,
      String baseUrl}) async {
    var trasactionId = Guid.newGuid;
    var deviceId = await getDeviceId();
    String osType = Platform.isIOS ? "IOS" : "Android";
    String osVersion = "12";
    print("calling exception method");
    var headers = {
      "content-type": "application/json",
      "accept": "application/json",
      "apiKey": "480CFB8B-9628-481A-AB98-0002567D75A0",
    };
    String url =
        "$baseUrl/ExceptionLogController/ExecuteExceptionLogLineSave/$trasactionId/hhh/$deviceId/$osType/$osVersion/$className/$methodName/$information1/$information2/$exceptionInfo";
    var response = await http.Client().get(url, headers: headers);
    print(url);
    print("resi");
    print(response.statusCode);
  }

  Future<String> getDeviceId() async {
    String id;

    final DeviceInfoPlugin deviceInfoPlugin = new DeviceInfoPlugin();

    try {
      if (Platform.isAndroid) {
        var build = await deviceInfoPlugin.androidInfo;
        id = build.androidId;

        print("printing device id");
        print(id);
      } else if (Platform.isIOS) {
        var build = await deviceInfoPlugin.iosInfo;
        id = build.identifierForVendor;
      }
    } on Exception {
      print('Failed to get Platform Information');
    }

    return id;
  }
}
