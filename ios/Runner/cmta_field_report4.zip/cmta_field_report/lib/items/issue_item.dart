import 'dart:convert';
import 'dart:typed_data';


import 'package:cmta_field_report/models/issue.dart';
import 'package:flutter/material.dart';

class IssueListItem extends StatelessWidget {
  String fid;
  String reportFid;
  String details;
  String location;
  String status;
  String image;

  IssueListItem({this.details, this.location, this.status, this.image});

  @override
  Widget build(BuildContext context) {


    return new Padding(
      padding: EdgeInsets.all(16.0),
      child: new Row(children: [
        new Column(children: <Widget>[
            Container(

                child: new Image.network(image),height: 100,width: 100,),
          ], crossAxisAlignment: CrossAxisAlignment.start,),
        new Expanded(
          child: new Padding(
            padding: EdgeInsets.all(24.0),
            child: new Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                new Text(
                  details,
                  textScaleFactor: 1.3,
                  textAlign: TextAlign.left,
                ),
                new Text(
                  location,
                  textScaleFactor: 1.0,
                  textAlign: TextAlign.right,
                  style: new TextStyle(
                    color: Colors.grey,
                  ),
                ),
                new Text(
                  status,
                  textScaleFactor: 1.0,
                  textAlign: TextAlign.right,
                  style: new TextStyle(
                    color: Colors.grey,
                  ),
                )
              ], 
            ),
          )
        ),
      ]),
    );
  }
}