class BaseUrl {
  final String baseURL;

  BaseUrl({this.baseURL});
}
